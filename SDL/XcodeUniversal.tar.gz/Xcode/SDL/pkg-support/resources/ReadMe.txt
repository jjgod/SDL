The Simple DirectMedia Layer (SDL for short) is a cross-platform library designed to make it easy to write multi-media software, such as games and emulators.

The Simple DirectMedia Layer library source code is available from: http://www.libsdl.org/

This library is distributed under the terms of the GNU LGPL license: http://www.gnu.org/copyleft/lesser.html


This packages contains the SDL.framework for OS X. Conforming with Apple guidelines, this framework contains both the SDL runtime component and development header files.


To Install:
Copy the SDL.framework to /Library/Frameworks

You may alternatively install it in <your home directory>/Library/Frameworks if your access privileges are not high enough. (Be aware that the Xcode templates we provide in the SDL Developer Extras package may require some adjustment for your system if you do this.)


Known Issues:
MMX/SSE optimizations for x86 are not compiled in.


(Partial) History of PB/Xcode projects:
2006-01-31 - Updates to build Universal Binaries while retaining 10.2 compatibility. We were unable to get MMX/SSE support enabled. It is believed that a rewrite of the assembly code will be necessary to make it position independent and not require nasm. Altivec has finally been enabled for PPC. (Eric Wing)

2005-08-21 - First entry in history. Updated for SDL 1.2.9 and Xcode 2.1. Getting ready for Universal Binaries. Removed the .pkg system for .dmg for due to problems with broken packages in the past several SDL point releases. Removed usage of SDL exports file because it has become another point of failure. Introduced new documentation about SDLMain and how to compile in an devel-lite section of the SDL.dmg. (Eric Wing)

Before history:
SDL 1.2.6? to 1.2.8
Started updating Project Builder projects to Xcode for Panther and Tiger. Also removed the system that split the single framework into separate runtime and headers frameworks. This is against Apple conventions and causes problems on multiuser systems. We now distribute a single framework.
The .pkg system has repeatedly been broken with every new release of OS X. With 1.2.8, started migrating stuff to .dmg based system to simplify distribution process. Tried updating the exports file and Perl script generation system for changing syntax. (Eric Wing)

Pre-SDL 1.2.6 
Created Project Builder projects for SDL and .pkg based distribution system. (Darrell Walisser)








