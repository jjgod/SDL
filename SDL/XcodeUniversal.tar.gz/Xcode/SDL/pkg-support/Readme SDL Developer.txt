SDL Mac OS X Developer Notes:
    This note contains brief information that should get you up and running quickly. Make sure you have already installed the SDL.framework from the SDL.dmg. For more complete documentation, please see READMEs included with the SDL source code. Also, don't forget about the API documentation in /Developer/Documentation/SDL.

How to create a new SDL project:

    1. Open Project Builder
    2. Select File->New Project
    3. Select SDL Application
    4. Save, and Finish
    5. Add your sources.
    *6. That's it!

	*For Xcode, you may want to convert the project to native Xcode targets since our current templates are Project Builder based. Go to the Menu->Project->Upgrade All Targets to Native

What was installed and where:
    Project Stationary in /Developer/ProjectBuilder Extras or /Library/Application Support/Apple/Developer Tools (for Xcode)
    HTML documentation in /Developer/Documentation/SDL
    This README in your home directory.
    Package receipt in /Library/Receipts/SDL-devel.pkg
    
What was not installed
    - SDL framework. (From SDL.dmg package)
    - SDL library source code and Framework Projects.  (Available in the SDL source code)
    - configure/make support (available with source code).
    
Project Builder Tips and Tricks:

- Building from command line
    Use pbxbuild in the same directory as your .pbproj file
         
- Running your app
    You can send command line args to your app by either invoking it from
    the command line (in *.app/Contents/MacOS) or by entering them in the
    "Executables" panel of the target settings, or the "Executables" tab
    in the main window in Project Builder 2.0.
    
- Working directory
    As defined in the SDLMain.m file, the working directory of 
    your SDL app is by default set to its parent. You may wish to 
    change this to better suit your needs.

See BUGS in the SDL source code for current bugs in the implementation.
